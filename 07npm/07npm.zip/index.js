// Package.json file contains all the projects names, Libraries, Packages, scripts etc.
const chalk = require("chalk");
console.log(chalk.blue("Hello"));

const validator = require("validator");
const res = validator.isEmail("mdsaqibansari007@gmail.com");
console.log(res ? chalk.green.inverse(res) : chalk.red.inverse(res));
const res2 = validator.isEmail("mdsaqibansari007gmail.com");
console.log(res2 ? chalk.green.inverse(res2) : chalk.red.inverse(res2));
